package databaseAttempt;

public interface GUIMode {
	public GUIMode menu();
	public GUIMode plot();
	
	
}
